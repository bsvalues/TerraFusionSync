# Ensure PowerShell runs as Admin
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Please run this script as Administrator!" -ForegroundColor Red
    exit 1
}

# Download and install Ollama
Invoke-WebRequest -Uri "https://ollama.com/download/OllamaSetup.exe" -OutFile "$env:TEMP\OllamaSetup.exe"
Start-Process -FilePath "$env:TEMP\OllamaSetup.exe" -Wait

# Start Ollama service
Start-Process -FilePath "C:\Program Files\Ollama\ollama.exe" -ArgumentList "serve" -WindowStyle Hidden

# Pull the Llama3 model
Start-Sleep -Seconds 10
Start-Process -FilePath "C:\Program Files\Ollama\ollama.exe" -ArgumentList "pull llama3"

Write-Host "Ollama has been installed and Llama3 model is being pulled." -ForegroundColor Green