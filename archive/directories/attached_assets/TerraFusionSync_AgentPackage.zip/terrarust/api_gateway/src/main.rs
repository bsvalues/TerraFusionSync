use actix_web::{web, App, HttpServer, Responder};

async fn health() -> impl Responder {
    "OK"
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| App::new().route("/health", web::get().to(health)))
        .bind("0.0.0.0:7000")?
        .run()
        .await
}
