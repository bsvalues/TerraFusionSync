# TerraFusionSync Platform

This is the core backend system for county GIS, valuation, reporting, and AI integration.

## Core Components

- `terrafusion_sync/`: Python-based plugin system (valuation, GIS, reporting)
- `terrarust/`: High-performance Rust-based services
- `ai_services/`: Future Ollama-based agents
- `infra/`: Docker, Prometheus, and deployment scaffolds
- `docs/`: IT and engineering documentation

## One-Click Local Setup

1. `pip install -r terrafusion_sync/requirements.txt`
2. `uvicorn terrafusion_sync.main:app --reload`
3. For Rust: `cargo run` inside each Rust service folder
4. `docker-compose up` for full platform

## For County IT Staff

Run the Windows installer or `run_all_rust.bat` for local startup. All components are isolated to local network.
