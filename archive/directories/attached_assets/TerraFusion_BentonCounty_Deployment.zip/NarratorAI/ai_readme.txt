This is the ai component of the TerraFusion Benton County Deployment Package.
