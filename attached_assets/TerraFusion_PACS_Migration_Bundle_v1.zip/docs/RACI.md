
| Task | Project Manager | DBA | DevOps | Auditor | Assessor |
|------|-----------------|-----|--------|---------|----------|
| Freeze notice | A | R |   | C | I |
| Extract & load | C | A/R | R | I | I |
| Row‑count recon | C | R | A | A | I |
| Parallel monitoring | A | R | R | C | I |
| Go/No‑go | A | C | C | C | A |
| Cut‑over | A | R | R | C | A |
